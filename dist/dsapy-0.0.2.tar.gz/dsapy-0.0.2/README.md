''' This is a very helpful module for programmers in their competitive programming journey or their DSA course it has all functions you want like, gcd ,binary search even this module has many famous problems solution like josephus problem agressive cows problem and more . pls use this and share with your friends.
Inspired by STL library in C++. '''

# you can also check the documentation (available soon)
# made by a Shashwat Tiwari (Replit - https://replit.com/@ShashwaTiwari)

-> Rudransh (creater)